# SECE
Spatial region-related embedding and Cell type-related embedding of spatial transcriptomics
